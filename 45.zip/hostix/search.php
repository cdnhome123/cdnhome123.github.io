<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Hostix
 */

get_header();
hostix_search_breadcrumb();
$hostix_blog_layout = cs_get_option('hostix_blog_layout');
$hostixPostClass = '';
if(is_active_sidebar('sidebar-1')){
	$hostixPostClass = 'col-xl-9 col-lg-8 col-md-12 col-sm-12';
}else{
	$hostixPostClass = 'col-lg-10 offset-lg-1';
}
?>
<div class="sidebar-page-container">
	<div class="auto-container">
		<div class="row clearfix">
			<?php if('1' == $hostix_blog_layout):?>
			<?php get_sidebar();?>
			<div class="content-side <?php echo esc_attr($hostixPostClass);?>">
				<?php hostix_search_loop();?>
			</div>
			<?php elseif('2' == $hostix_blog_layout):?>
			<div class="content-side col-lg-10 offset-lg-1">
				<?php hostix_search_loop();?>
			</div>
			<?php else:?>
			<div class="content-side <?php echo esc_attr($hostixPostClass);?>">
				<?php hostix_search_loop();?>
			</div>
			<?php get_sidebar();?>
			<?php endif;?>
		</div>
	</div>
</div>
<?php
get_footer();
