<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Hostix
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('news-block-two'); ?>>
	<div class="inner-box">
		<?php if(has_post_thumbnail()){?>
		<div class="image">
			<a href="<?php the_permalink();?>"><?php the_post_thumbnail( 'hostix-image-size-1' )?></a>
			<div class="post-date"><?php echo wp_kses( get_the_date('d'), true ); ?>
			<br> <span><?php echo wp_kses( get_the_date('M'), true ); ?></div>
		</div>
		<?php }?>
		<div class="lower-content">
			<div class="tags">				
				<?php hostix_entry_footer();?>
			</div>
			<h3><a href="<?php the_permalink()?>"><?php the_title();?></a></h3>
			<ul class="post-meta d-flex align-items-center flex-wrap clearfix">
				<li><span class="author"><?php hostix_main_author_avatars(25); ?></span> <?php the_author()?>  <?php 
                if(function_exists('hostix_ready_time_ago')){ ?>
                    / <span class="year"><?php echo hostix_ready_time_ago();?></span>
                <?php }
                ?>    </li>
				<li><span class="icon flaticon-027-click-1"></span><?php echo esc_attr(get_comments_number());?></li>
				<li><span class="icon flaticon-032-speedometer"></span><?php echo hostix_reading_time();?></li>
			</ul>
			<div class="text"><?php the_excerpt();?></div>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
