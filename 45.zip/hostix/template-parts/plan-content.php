<div class="plan__content">
    <?php the_content();?>
</div>