<!-- Main Footer -->
<footer class="footer-style-two style-two">
	<?php hostix_footer_markup_two();?>
</footer>
<!-- End Main Footer -->