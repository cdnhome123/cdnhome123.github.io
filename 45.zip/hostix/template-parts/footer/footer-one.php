<!-- Main Footer -->
<?php 
$no_sidebar_clas = '';
if(!is_active_sidebar('footer-1') || !is_active_sidebar('footer-2') || !is_active_sidebar('footer-3') || !is_active_sidebar('footer-4')){
  $no_sidebar_clas = 'no__sidebar-clas';
}
?>
<footer class="main-footer <?php echo esc_attr($no_sidebar_clas);?>">
	<?php hostix_footer_markup();?>
</footer>
<!-- End Main Footer -->