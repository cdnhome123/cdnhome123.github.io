<!-- Main Footer -->
<footer class="main-footer style-two">
	<?php hostix_footer_markup();?>
</footer>
<!-- End Main Footer -->