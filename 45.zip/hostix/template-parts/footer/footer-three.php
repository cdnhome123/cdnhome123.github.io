<?php 
$footer_3_shape = cs_get_option('footer_3_shape');
?>
<!-- Main Footer -->
<footer class="main-footer style-three">
    <?php if(!empty($footer_3_shape['url'])):?>
        <div class="vector-layer" style="background-image: url(<?php echo esc_url($footer_3_shape['url']);?>)"></div>
    <?php endif;?>
<div class="triangle-color-layer"></div>
	<?php hostix_footer_markup();?>
</footer>
<!-- End Main Footer -->