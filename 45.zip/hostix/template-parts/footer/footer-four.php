<footer class="footer-style-two">
	<?php hostix_footer_markup_two();?>
</footer>