<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Hostix
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="inner-box">
        <div class="image">
            <?php the_post_thumbnail( 'hostix-image-size-1' )?>
            <div class="post-date"><?php echo wp_kses( get_the_date('d'), true ); ?>
			<br> <span><?php echo wp_kses( get_the_date('M'), true ); ?></div>
        </div>
        <div class="lower-content">
            <div class="tags">
                <?php hostix_entry_footer();?>
            </div>
            <ul class="post-meta d-flex align-items-center flex-wrap clearfix">
				<li><span class="author"><?php hostix_main_author_avatars(25); ?></span> <?php the_author()?>  <?php
                if(function_exists('hostix_ready_time_ago')){ ?>
                    / <span class="year"><?php echo hostix_ready_time_ago();?></span>
                <?php }
                ?>    </li>
				<li><span class="icon date fal fa-calendar-alt"></span>
                <?php
                    $date_format = get_option( 'date_format' );
                    echo esc_html( get_the_date( $date_format ) );
                ?>
                </li>
				<li><span class="icon flaticon-032-speedometer"></span><?php echo hostix_reading_time();?></li>
			</ul>
            <div class="entry-content">
                <?php
                    the_content(
                        sprintf(
                            wp_kses(
                                /* translators: %s: Name of current post. Only visible to screen readers */
                                __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'hostix' ),
                                array(
                                    'span' => array(
                                        'class' => array(),
                                    ),
                                )
                            ),
                            wp_kses_post( get_the_title() )
                        )
                    );

                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'hostix' ),
                            'after'  => '</div>',
                        )
                    );
                ?>
            </div>
            <div class="post-share-options">
                <div class="post-share-inner clearfix">
                    <div class="tags-box">
                        <?php hostix_entry_footer();?>
                    </div>
                    <?php if(function_exists('hostix_single_post_share')){hostix_single_post_share();}?>
                </div>
            </div>
        </div>
    </div>
</article><!-- #post-<?php the_ID(); ?> -->
