<?php 
$top_bar_text = cs_get_option('top_bar_text');
$phone_number = cs_get_option('phone_number');

?>
<header class="main-header header-style-two">
    	
<!-- Header Top / Style Two -->
<div class="header-top style-two">
	<div class="auto-container">
		<div class="d-flex justify-content-between align-items-center flex-wrap">
			<?php if(!empty($phone_number)):?>
				<a class="phone" href="<?php echo esc_url($phone_number['url']);?>"><?php echo esc_html($phone_number['text']);?></a>
			<?php endif;?>
			<?php if(!empty($top_bar_text)):?>
				<div class="text"><?php echo wp_kses( $top_bar_text, true );?></div>
			<?php endif;?>
			<!-- Right Box -->
			<div class="right-box d-flex align-items-center">
				
				<!-- Language DropDown -->
				<?php hostix_languages();?>
				
				<!-- Register DropDown -->
				<?php hostix_login_reg()?>
				
			</div>
		</div>
	</div>
</div>

<!-- Header Lower -->
<div class="header-lower">
	
	<div class="auto-container">
		<div class="inner-container d-flex justify-content-between align-items-center">
			
			<!-- Logo Box -->
			<div class="logo-box">
				<div class="logo"><?php hostix_logo_v2();?></div>
			</div>
			
			<div class="nav-outer d-flex align-items-center">
				
				<!-- Main Menu -->
				<nav class="main-menu show navbar-expand-md">
					<div class="navbar-header">
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					
					<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
						<?php hostix_main_menu(); ?>
					</div>
					
				</nav>
				<!-- Main Menu End-->
				
			</div>
			
			<!-- Outer Box -->
			<div class="outer-box d-flex align-items-center">
				
				<!-- Contact DropDown -->
				<?php hostix_contact_option();?>
				
				<!-- Nav Toggle -->
				<div id="open_offcanvas">
					<div class="bars-outer clearfix">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				
			</div>
			<!-- End Outer Box -->
			
		</div>
		
	</div>
</div>
<!-- End Header Lower -->

<!-- Sticky Header  -->
<div class="sticky-header">
	<div class="auto-container">
		<div class="d-flex justify-content-between align-items-center">
			<!-- Logo -->
			<div class="logo">
				<?php hostix_logo_v2();?>
			</div>
			
			<!-- Right Col -->
			<div class="right-box">
				<!-- Main Menu -->
				<nav class="main-menu">
					<!--Keep This Empty / Menu will come through Javascript-->
				</nav>
				<!-- Main Menu End-->
				
			</div>
			
		</div>
	</div>
</div>
<!-- End Sticky Menu -->

<!-- Mobile Menu  -->
<div class="mobile-menu">
	<div class="menu-backdrop"></div>
	<div class="close-btn"><span class="icon flaticon-020-x-mark"></span></div>
	<nav class="menu-box">
		<div class="nav-logo"><?php hostix_logo_v2();?></div>
		<div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
	</nav>
</div>
<!-- End Mobile Menu -->

</header>
<?php hostix_offcanvas_nav();?>