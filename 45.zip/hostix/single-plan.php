<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Hostix
 */

get_header();
?>

<div class="hostix__plan-section">
	<?php hostix_single_plan_loop();?>
</div>

<?php
get_footer();