<?php

// File Security Check
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

function hostix_theme_options_style() {

    //
    // Enqueueing StyleSheet file
    //
    wp_enqueue_style( 'hostix-theme-custom-style', get_template_directory_uri() . '/assets/css/custom-style.css' );
    $css_output = '';
    $hostix_primery_color = cs_get_option('hostix_primery_color'); 
    $hostix_gradient_color = cs_get_option('hostix_gradient_color'); 
    $hostix_gradient_two_color = cs_get_option('hostix_gradient_two_color'); 
    $hostix_gradient_three_color = cs_get_option('hostix_gradient_three_color'); 
    
    //Theme Gradient COlor
    //Theme Gradient COlor
    if(!empty($hostix_primery_color )){
        $css_output .= '      
        :root {
            --main-color: '.esc_attr($hostix_primery_color).';          
            --color-fourtyfour: '.esc_attr($hostix_primery_color).';          
            --color-fourtyseven: '.esc_attr($hostix_primery_color).';          
            --color-fourtyone: '.esc_attr($hostix_primery_color).';          
            --color-fourtytwo: '.esc_attr($hostix_primery_color).';          
            --color-fourtythree: '.esc_attr($hostix_primery_color).';          
            --color-eightythree: '.esc_attr($hostix_primery_color).';          
            --color-seventy: '.esc_attr($hostix_primery_color).';          
            --color-eightyfive: '.esc_attr($hostix_primery_color).';          
            --color-eleven: '.esc_attr($hostix_primery_color).';          
            --color-eleven: '.esc_attr($hostix_primery_color).';          
          } 
        ';
    }
    
    if(!empty($hostix_gradient_color )){
        $css_output .= '      
        :root {
            --gradient1:'.esc_attr($hostix_gradient_color['1']).';
            --gradient2:'.esc_attr($hostix_gradient_color['2']).';      
          } 
        ';
    }

    if(!empty($hostix_gradient_two_color )){
        $css_output .= '      
        :root {  
            --gradient3:'.esc_attr($hostix_gradient_two_color['1']).';
            --gradient4:'.esc_attr($hostix_gradient_two_color['2']).';       
          } 
        ';
    }

    if(!empty($hostix_gradient_three_color )){
        $css_output .= '      
        :root {
            --color-seventynine:'.esc_attr($hostix_gradient_three_color['1']).';
            --color-eighty:'.esc_attr($hostix_gradient_three_color['2']).';       
          } 
        ';
    }
   

    wp_add_inline_style( 'hostix-theme-custom-style', $css_output );

}
add_action( 'wp_enqueue_scripts', 'hostix_theme_options_style' );
