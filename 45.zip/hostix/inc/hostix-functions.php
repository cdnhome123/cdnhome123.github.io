<?php

function hostix_preloader(){
$preloader_enable = cs_get_option('preloader_enable');
if($preloader_enable == true):
?>
  <div class="hostix__preloader">
    <svg class="pl" width="240" height="240" viewBox="0 0 240 240">
      <circle class="pl__ring pl__ring--a" cx="120" cy="120" r="105" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 660" stroke-dashoffset="-330" stroke-linecap="round" />
      <circle class="pl__ring pl__ring--b" cx="120" cy="120" r="35" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 220" stroke-dashoffset="-110" stroke-linecap="round" />
      <circle class="pl__ring pl__ring--c" cx="85" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round" />
      <circle class="pl__ring pl__ring--d" cx="155" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round" />
    </svg>
  </div>
<?php
endif;
}


/**
 * Main Menu
 *
 * @return void
 */
function hostix_main_menu(){
    echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown'], wp_nav_menu( array(
        'echo'           => false,
        'theme_location' => 'main_menu',
        'menu_id'        =>'hostix-primary-menu',
        'menu_class'     =>'navigation clearfix',
        'container'=>false,
        'fallback_cb'    => 'Hostix_Bootstrap_Navwalker::fallback',
    )) );
}

/**
 * Hostix Header Option
 *
 * @return void
 */
function hostix_header_option(){
    if('header-style-one' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'one');
    }elseif('header-style-two' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'two');
    }elseif('header-style-three' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'three');
    }elseif('header-style-four' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'four');
    }elseif('header-style-five' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'five');
    }elseif('header-style-six' === hostix_site_header()){
        get_template_part('template-parts/header/header', 'six');
    }else{
      get_template_part('template-parts/header/header', 'three');
    }
}

/**
 * Hostix Header Option
 *
 * @return void
 */
function hostix_footer_option(){
  if('footer-style-one' === hostix_site_footer()){
      get_template_part('template-parts/footer/footer', 'one');
  }elseif('footer-style-two' === hostix_site_footer()){
      get_template_part('template-parts/footer/footer', 'two');
  }elseif('footer-style-three' === hostix_site_footer()){
      get_template_part('template-parts/footer/footer', 'three');
  }elseif('footer-style-four' === hostix_site_footer()){
      get_template_part('template-parts/footer/footer', 'four');
  }elseif('footer-style-five' === hostix_site_footer()){
      get_template_part('template-parts/footer/footer', 'five');
  }else{
      get_template_part('template-parts/footer/footer', 'one');
  }
}

function hostix_offcanvas_nav(){
  $contact_info_items = cs_get_option('contact_info_items');
  $offc_social_icons = cs_get_option('offc_social_icons');
  $is_enable_offcanvas_nav = cs_get_option('is_enable_offcanvas_nav');
  $header_3_login = cs_get_option('header_3_login');

?>
    <section class="offcanvas__area">
    <div class="close_offcanvas close-side-widget" id="close_offcanvas"></div>
    <div class="offcanvas__inner">
      <div class="offcanvas__left ">

        <div class="side__navbar-wrapper mean-container">
          <nav class="side__navbar">
            <?php
            echo str_replace(['menu-item-has-children'], ['has-megamenu'], wp_nav_menu( array(
                'echo'           => false,
                'theme_location' => 'main_menu',
                'menu_id'        =>'hostix-ofc-primary-menu',
                'menu_class'     =>'navigation clearfix',
                'container'=>false,
                'fallback_cb'    => 'Hostix_Bootstrap_Navwalker::fallback',
            )) );?>
          </nav>
        </div>
      </div>
      <?php if(!empty($header_3_login['text']) || !empty($header_3_login['url'])):?>
        <div class="login-box">
            <a href="<?php echo esc_url($header_3_login['url']);?>"><?php echo esc_html($header_3_login['text']);?></a>
        </div>
        <?php endif;?>
      <div class="offcanvas__right">
        <div class="offcanvas__logo">
          <?php hostix_logo();?>
        </div>
        <div class="offcanvas__contact">
          <?php if(!empty($contact_info_items)):?>
          <ul class="info-list">
            <?php foreach($contact_info_items as $item):?>
              <li>
                <span class="icon <?php echo esc_attr($item['icons']);?>"></span>
                <span class="title"><?php echo wp_kses( $item['title'], true )?></span>
                <a><?php echo wp_kses( $item['infos'], true )?></a>
              </li>
            <?php  endforeach;?>
          </ul>
          <?php endif;?>
        <!-- Social Box -->
        <?php if(!empty($offc_social_icons)):?>
          <ul class="social-box">
            <?php foreach($offc_social_icons as $item):?>
             <li><a href="<?php echo esc_url($item['link']);?>" class="<?php echo esc_attr($item['icon']);?>"></a></li>
            <?php  endforeach;?>
        </ul>
        <?php endif;?>
        </div>
      </div>
    </div>
  </section>
  <?php
}

function hostix_search_popup(){ ?>
  <div class="search-popup">
	<div class="color-layer"></div>
	<button class="close-search"><span class="flaticon-020-x-mark"></span></button>
	<form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<div class="form-group">
			<input type="search" name="s" value="<?php the_search_query();?>" placeholder="<?php esc_attr_e( 'Search Here', 'hostix' );?>" required="">
			<button type="submit"><i class="flaticon-001-loupe"></i></button>
		</div>
	</form>
</div>
<?php }

/**
 * Contact Option
 *
 * @return void
 */
function hostix_contact_option(){
    $head1_contact_info_items = cs_get_option('head1_contact_info_items');
    $info_title = cs_get_option('info_title');
    $contact_info = cs_get_option('contact_info');
    $chat_title = cs_get_option('chat_title');
    $chat_icon = cs_get_option('chat_icon');
    $chat_name = cs_get_option('chat_name');
    $contact_btn = cs_get_option('contact_btn');
?>
    <div class="contact-dropdown dropdown">
        <?php if(!empty($contact_btn)):?>
            <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false"><?php echo esc_html($contact_btn)?></button>
        <?php endif;?>
        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <?php if(!empty($contact_info)):?>
                <div class="text"><?php echo wp_kses( $contact_info, true )?></div>
            <?php endif;?>

            <?php if(!empty($info_title)):?>
                <h6><?php echo wp_kses( $info_title, true )?></h6>
            <?php endif;?>

            <?php if(!empty($head1_contact_info_items)):?>
            <ul class="contact-list">
                <?php foreach($head1_contact_info_items as $item):?>
                <li>
                    <span class="icon"><img src="<?php echo esc_url($item['contact_info_img']['url']);?>" alt="" /></span>
                    <strong><?php echo esc_html($item['call_title']);?></strong>
                    <div class="text"><?php echo esc_html($item['call_no']);?></div>
                </li>
                <?php endforeach;?>
            </ul>
            <?php endif;?>
            <?php if(!empty($chat_title)):?>
                <h6><?php echo wp_kses( $chat_title, true )?></h6>
            <?php endif;?>
            <?php if(!empty($chat_name['text']) && !empty($chat_name['url'])):?>
            <ul class="contact-list style-two">
                <li>
                    <a class="link" href="<?php echo esc_url($chat_name['url']);?>"></a>
                    <span class="icon"><img src="<?php echo esc_url($chat_icon['url']);?>" alt="<?php echo esc_attr($chat_icon['alt']);?>" /></span>
                    <strong><?php echo esc_html($chat_name['text']);?></strong>
                </li>
            </ul>
            <?php endif;?>
        </div>
    </div>
<?php
}

function footer_social_contact(){
  $footer_social_connect = cs_get_option('footer_social_connect');
  if(!empty($footer_social_connect)){
  foreach($footer_social_connect as $connect):
  ?>
    <div class="social-column col-xl-3 col-lg-6 col-md-6 col-sm-12">
        <div class="inner-column">
            <a href="<?php if(!empty($connect['link']['url'])){ echo esc_url($connect['link']['url']);}?>" class="overlay-link"></a>
            <div class="content">
                <span class="icon"><img src="<?php echo esc_url($connect['icon_img']['url']);?>" alt="<?php echo esc_attr($connect['icon_img']['alt']);?>" /></span>
                <strong><?php echo esc_html($connect['title']);?></strong>
                <?php echo esc_html($connect['text']);?>
            </div>
        </div>
    </div>
  <?php
  endforeach;
}
}

/**
 * Hostix Footer Content Markup
 *
 * @return void
 */
function hostix_footer_markup(){
  $contact_title = cs_get_option('contact_title');
  $contact_text = cs_get_option('contact_text');
  $social_icon_fo = cs_get_option('social_icon_fo');
  $footer_chat_icon = cs_get_option('footer_chat_icon');
  $footer_chat = cs_get_option('footer_chat');
  $hostix_copywrite_text = cs_get_option('hostix_copywrite_text');
  $payment_card = cs_get_option('payment_card');

?>
  <!-- End Email Box -->
  <div class="auto-container">
      <?php if('footer-style-one' === hostix_site_footer()):?>
        <!-- Upper Box -->
        <div class="upper-box">
            <div class="row clearfix">
                <?php footer_social_contact();?>
            </div>
        </div>
        <?php endif;?>
        <!-- Widgets Section -->
        <?php if(is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3') || is_active_sidebar('footer-4')):?>
        <div class="widgets-section">
            <div class="row clearfix">
                <!-- Column -->
                <div class="big-column col-lg-6 col-md-12 col-sm-12">
                    <div class="row clearfix">

                        <!-- Footer Column -->
                        <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <!-- Logo -->
                                <div class="logo">
                                  <?php hostix_logo_v2();?>
                                </div>
                                <?php if(!empty($contact_title)):?>
                                  <div class="address"><?php echo esc_html($contact_title);?></div>
                                <?php endif;?>

                                <?php if(!empty($contact_text)):?>
                                  <div class="text"><?php echo wp_kses( $contact_text, true );?></div>
                                <?php endif;?>

                                <!-- Social Box -->
                                <?php if(!empty($social_icon_fo)):?>
                                <ul class="social-box">
                                    <?php foreach($social_icon_fo as $icon):?>
                                        <li><a href="<?php echo esc_url($icon['link']);?>" class="<?php echo esc_attr($icon['icon'])?>"></a></li>
                                    <?php endforeach;?>
                                </ul>
                                <?php endif;?>
                                <?php if(!empty($footer_chat['text'])){?>
                                <a class="start-chat" href="<?php echo esc_url($footer_chat['url']);?>">

                                  <?php if(!empty($footer_chat_icon['url'])):?>
                                    <span class="icon"> <img src="<?php echo esc_url($footer_chat_icon['url']);?>" alt="<?php echo esc_attr($footer_chat_icon['alt']);?>" /></span>
                                  <?php endif;?>
                                  <?php if(!empty($footer_chat['text'])){echo esc_html($footer_chat['text']);} ?>

                                </a>
                                <?php }?>
                            </div>
                        </div>

                        <!-- Footer Column -->
                        <?php if(is_active_sidebar('footer-1')):?>
                        <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                            <div class="page-list">
                              <?php dynamic_sidebar( 'footer-1' ); ?>
                            </div>
                        </div>
                        <?php endif;?>
                    </div>
                </div>

                <!-- Column -->
                <div class="big-column col-lg-6 col-md-12 col-sm-12">
                    <div class="row clearfix">

                        <!-- Footer Column -->
                        <?php if(is_active_sidebar('footer-2')):?>
                          <div class="footer-column col-lg-4 col-md-6 col-sm-12">
                            <div class="page-list">
                              <?php dynamic_sidebar( 'footer-2' ); ?>
                            </div>
                          </div>
                        <?php endif;?>
                        <!-- Footer Column -->
                        <?php if(is_active_sidebar('footer-3')):?>
                        <div class="footer-column col-lg-4 col-md-6 col-sm-12">
                          <div class="page-list">
                            <?php dynamic_sidebar( 'footer-3' ); ?>
                          </div>
                        </div>
                        <?php endif;?>
                        <!-- Footer Column -->
                        <?php if(is_active_sidebar('footer-4')):?>
                        <div class="footer-column col-lg-4 col-md-6 col-sm-12">
                          <div class="page-list">
                            <?php dynamic_sidebar( 'footer-4' ); ?>
                          </div>
                        </div>
                        <?php endif;?>
                    </div>
                </div>

            </div>
        </div>
        <?php endif;?>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div class="copyright">
                  <?php
                    if(!empty($hostix_copywrite_text)){
                        echo wp_kses( $hostix_copywrite_text, true );
                    }else{
                        esc_html_e( '&copy; 2023 Hostix - Premium Web Hosting WordPress Theme', 'hostix' );
                    }
                  ?>

                </div>
                <?php if(!empty($payment_card['url'])):?>
                  <div class="cards"><img src="<?php echo esc_url($payment_card['url']);?>" alt="<?php echo esc_attr($payment_card['alt']);?>" /></div>
                <?php endif;?>
            </div>
        </div>

    </div>
<?php
}

/**
 * Footer Markup Two
 */
function hostix_footer_markup_two(){
  $contact_title = cs_get_option('contact_title');
  $contact_text = cs_get_option('contact_text');
  $social_icon_fo = cs_get_option('social_icon_fo');
  $footer_chat_icon = cs_get_option('footer_chat_icon');
  $footer_chat = cs_get_option('footer_chat');
  $hostix_copywrite_text = cs_get_option('hostix_copywrite_text');
  $f_newsletter_shortcode = cs_get_option('f_newsletter_shortcode');
  $f_newsletter_title = cs_get_option('f_newsletter_title');
  $cont_f_icon_fo = cs_get_option('cont_f_icon_fo');
  $f_ct_title = cs_get_option('f_ct_title');
?>
  <!-- End Email Box -->
	<div class="auto-container">

		<!-- Widgets Section -->
		<div class="widgets-section">
			<div class="row clearfix">
				<!-- Column -->
				<div class="big-column col-lg-7 col-md-12 col-sm-12">
					<div class="row clearfix">

						<!-- Footer Column -->
            <?php if(!empty($cont_f_icon_fo)):?>
						<div class="footer-column col-lg-4 col-md-4 col-sm-12">
							<div class="footer-widget contact-widget">
                <?php if(!empty($f_ct_title)):?>
								  <h6><?php echo esc_html($f_ct_title);?></h6>
                <?php endif;?>
								<ul class="contact-list">
                  <?php foreach($cont_f_icon_fo as $item):?>
									  <li><span class="icon <?php echo esc_attr($item['icon']);?>"></span><?php echo wp_kses( $item['info_text'], true )?></li>
                  <?php endforeach;?>
								</ul>
							</div>
						</div>
						<?php endif;?>
						<!-- Footer Column -->
						<div class="footer-column col-lg-4 col-md-4 col-sm-12">
                <div class="page-list">
                  <?php dynamic_sidebar( 'footer-1' ); ?>
                </div>
						</div>

						<!-- Footer Column -->
						<div class="footer-column col-lg-4 col-md-4 col-sm-12">
							<div class="footer-widget links-widget">
                <div class="page-list">
                  <?php dynamic_sidebar( 'footer-2' ); ?>
                </div>
							</div>
						</div>

					</div>
				</div>

				<!-- Column -->
				<div class="big-column col-lg-5 col-md-12 col-sm-12">
					<div class="row clearfix">

						<!-- Footer Column -->
						<div class="footer-column col-lg-5 col-md-6 col-sm-12">
                <div class="page-list">
                  <?php dynamic_sidebar( 'footer-3' ); ?>
                </div>
						</div>

						<!-- Footer Column -->
            <?php if(!empty($f_newsletter_shortcode)):?>
						<div class="footer-column col-lg-7 col-md-6 col-sm-12">
							<div class="footer-widget logo-widget">
                <?php if(!empty($f_newsletter_title)):?>
								  <h6><?php echo esc_html($f_newsletter_title);?></h6>
                <?php endif;?>
								<!-- Subscribe Form -->
								<div class="subscribe-form-two">
									<form method="post" action="contact.html">
										<div class="form-group">
											<?php echo do_shortcode( $f_newsletter_shortcode );?>
										</div>
									</form>
								</div>
							</div>
						</div>
						<?php endif;?>
					</div>
				</div>

			</div>
		</div>

		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="d-flex justify-content-between align-items-center flex-wrap">
				<!-- Social Box -->
        <?php if(!empty($social_icon_fo)):?>
          <ul class="social-box">
              <?php foreach($social_icon_fo as $icon):?>
                  <li><a href="<?php echo esc_url($icon['link']);?>" class="<?php echo esc_attr($icon['icon'])?>"></a></li>
              <?php endforeach;?>
          </ul>
          <?php endif;?>
				<div class="copyright">
        <?php
            if(!empty($hostix_copywrite_text)){
                echo wp_kses( $hostix_copywrite_text, true );
            }else{
                esc_html_e( '&copy; 2004-2022 hostinger.com - Premium Web Hosting, Cloud Services.', 'hostix' );
            }
          ?>
        </div>
			</div>
		</div>

	</div>
  <?php
}


/**
 * Hostix Single Plan
 *
 * @return void
 */
function hostix_single_plan_loop(){
  while ( have_posts() ) :
    the_post();

    get_template_part( 'template-parts/plan', 'content' );

  endwhile; // End of the loop.
}

/**
 * Hostix Post Loop
 *
 * @return void
 */
function hostix_post_loop(){

		if ( have_posts() ) :

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_type() );

			endwhile; ?>
      <div class="styled-pagination text-center">
        <?php hostix_pagination();?>
      </div>


		<?php else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
}

function hostix_single_post(){
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'single' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
}

/**
 * Login Registration
 *
 * @return void
 */
function hostix_login_reg() {
  $enable_login_info = cs_get_option('enable_login_info');
  $signin_text = cs_get_option('signin_text');
  $login_info = cs_get_option('login_info');
  $registration_info = cs_get_option('registration_info');
  ?>
  <?php if ($enable_login_info): ?>
      <div class="register dropdown">
          <?php if (!empty($signin_text)): ?>
              <button class="btn dropdown-toggle" type="button" id="dropdownMenu1" data-bs-toggle="dropdown" aria-expanded="false"><?php echo esc_html($signin_text); ?>&nbsp;<span class="fa fa-angle-down"></span></button>
          <?php endif; ?>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
          <?php if (isset($login_info['url']) && isset($login_info['text']) && (!empty($login_info['url']) || !empty($login_info['text']))): ?>
              <li><a href="<?php echo esc_url($login_info['url']); ?>"><?php echo esc_html($login_info['text']); ?></a></li>
          <?php endif; ?>

          <?php if (isset($registration_info['url']) && isset($registration_info['text']) && (!empty($registration_info['url']) || !empty($registration_info['text']))): ?>
              <li><a href="<?php echo esc_url($registration_info['url']); ?>"><?php echo esc_html($registration_info['text']); ?></a></li>
          <?php endif; ?>

          </ul>
      </div>
  <?php endif; ?>
  <?php
}

function hostix_languages(){
  $langs_enable = cs_get_option('langs_enable');
  $add_languafes_options = cs_get_option('add_languafes_options');
  $active_lang_name = cs_get_option('active_lang_name');
  $active_lang_flag = cs_get_option('active_lang_flag');
?>
  <?php if($langs_enable == true):?>
    <div class="language dropdown">
        <?php if(!empty($active_lang_name)):?>
        <button class="btn dropdown-toggle" type="button" id="dropdownMenu" data-bs-toggle="dropdown" aria-expanded="false"><span class="flag"><img src="<?php echo esc_url($active_lang_flag['url']);?>" alt="<?php echo esc_attr($active_lang_flag['alt']);?>" /></span><?php echo esc_html($active_lang_name);?> &nbsp;<span class="fa fa-angle-down"></span></button>
        <?php endif;?>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
            <?php foreach($add_languafes_options as $lang):?>
                <li><a href="<?php echo esc_url($lang['lang_link']);?>"><?php echo esc_html($lang['lang_name']);?></a></li>
            <?php endforeach;?>
        </ul>
    </div>
    <?php endif;?>
<?php
}

/**
 * Header Contact Info
 *
 * @return void
 */
function header_contact_info(){
  $contact_infos_hd = cs_get_option('contact_infos_hd');
  if(!empty($contact_infos_hd)){
?>
  <div class="left-box">
        <ul class="contact-list">
            <?php foreach($contact_infos_hd as $item):?>
              <li><a href="<?php echo esc_url($item['info_link']);?>"><span class="icon <?php echo esc_attr($item['ct_icon']);?>"></span><?php echo esc_html($item['info_text']);?></a></li>
            <?php endforeach;?>
        </ul>
    </div>
<?php
  }
}
/**
 * Aditional Info
 *
 * @return void
 */
function header_aditian_info(){
  $hm__login = cs_get_option('hm__login');
  $hm__registration = cs_get_option('hm__registration');
  $hm__support = cs_get_option('hm__support');
?>
  <div class="right-box">
      <ul class="info-list-two">

        <?php if(!empty($hm__login['text']) || !empty($hm__login['url'])):?>
          <li><a href="<?php echo esc_url($hm__login['url']);?>"><span class="icon flaticon-033-rush"></span><?php echo esc_html($hm__login['text']);?></a></li>
        <?php endif;?>

        <?php if(!empty($hm__registration['text']) || !empty($hm__registration['url'])):?>
          <li><a href="<?php echo esc_url($hm__registration['url']);?>"><span class="icon flaticon-033-rush"></span><?php echo esc_html($hm__registration['text']);?></a></li>
        <?php endif;?>

        <?php if(!empty($hm__support['text']) || !empty($hm__support['url'])):?>
          <li><a href="<?php echo esc_url($hm__support['url']);?>"><span class="icon flaticon-033-rush"></span><?php echo esc_html($hm__support['text']);?></a></li>
        <?php endif;?>

      </ul>
    </div>
<?php
}

/**
 * Hostix Index Breadcrumb
 *
 * @return void
 */
function hostix_index_breadcrumb(){
  $br_custom_title = cs_get_option('br_custom_title');
  $br_sub_custom_title = cs_get_option('br_sub_custom_title');
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($br_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $br_sub_custom_title, true )?></div>
      <?php endif;?>
			<h1>
        <?php
          if(!empty($br_custom_title)){
            echo esc_html($br_custom_title);
          }else{
            esc_html_e( 'Blog Page', 'hostix' );
          }
        ?>
      </h1>
		</div>
	</section>
<?php
}
/**
 * Hostix Index Breadcrumb
 *
 * @return void
 */
function hostix_404_breadcrumb(){
  $er_custom_title = cs_get_option('er_custom_title');
  $er_sub_custom_title = cs_get_option('br_sub_custom_title');
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($er_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $er_sub_custom_title, true )?></div>
      <?php endif;?>
			<h1>
        <?php
          if(!empty($er_custom_title)){
            echo esc_html($er_custom_title);
          }else{
            the_title();
          }
        ?>
      </h1>
		</div>
	</section>
<?php
}

/**
 * Hostix Single Post Breadcrumb
 *
 * @return void
 */
function hostix_single_post_breadcrumb(){
  $br_single_sub_custom_title = cs_get_option('br_single_sub_custom_title');
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($br_single_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $br_single_sub_custom_title, true )?></div>
      <?php endif;?>
			<h1><?php the_title();?></h1>
		</div>
	</section>
<?php
}

/**
 * Hostix Single Post Breadcrumb
 *
 * @return void
 */
function hostix_page_breadcrumb(){
  if(get_post_meta(get_the_ID(), 'hostix_page_meta', true)) {
      $page_meta = get_post_meta(get_the_ID(), 'hostix_page_meta', true);
  } else {
      $page_meta = array();
  }

  if( array_key_exists( 'is_active_breadcrumb', $page_meta )) {
      $is_active_breadcrumb = $page_meta['is_active_breadcrumb'];
  } else {
      $is_active_breadcrumb = true;
  }

  if( array_key_exists( 'br_custom_title', $page_meta )) {
      $br_custom_title = $page_meta['br_custom_title'];
  } else {
      $br_custom_title = '';
  }
  if($is_active_breadcrumb == true):
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($br_single_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $br_single_sub_custom_title, true )?></div>
      <?php endif;?>
      <?php if(!empty($br_custom_title)):?>
          <h1><?php echo wp_kses( $br_custom_title, true ); ?></h1>
      <?php else:?>
          <h1><?php the_title(); ?></h1>
      <?php endif;?>
		</div>
	</section>
<?php
endif;
}

/**
 * Hostix Shop Breadcrumb
 *
 * @return void
 */
function hostix_shop_breadcrumb(){

?>
  <section class="page-title">
		<div class="auto-container">
      <h1><?php esc_html_e( 'Shop', 'hostix' ); ?></h1>
		</div>
	</section>
<?php
}

/**
 * Hostix Archive Breadcrumb
 *
 * @return void
 */
function hostix_archive_breadcrumb(){
  $br_sub_custom_title = cs_get_option('br_sub_custom_title');
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($br_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $br_sub_custom_title, true )?></div>
      <?php endif;?>
			<h1><?php
      the_archive_title();
      the_archive_description( '<div class="archive-description">', '</div>' );
      ?></h1>
		</div>
	</section>
<?php
}
/**
 * Hostix Archive Breadcrumb
 *
 * @return void
 */
function hostix_search_breadcrumb(){
  $br_sub_custom_title = cs_get_option('br_sub_custom_title');
?>
  <section class="page-title">
		<div class="auto-container">
      <?php if(!empty($br_sub_custom_title)):?>
			  <div class="title"><?php echo wp_kses( $br_sub_custom_title, true )?></div>
      <?php endif;?>
			<h3><?php
        /* translators: %s: search query. */
        printf( esc_html__( 'Search Results for: %s', 'hostix' ), '<span>' . get_search_query() . '</span>' );
        ?></h3>
		</div>
	</section>
<?php
}

/**
 * Archive Loop
 *
 * @return void
 */
function hostix_arcive_loop(){ ?>
  <?php if ( have_posts() ) : ?>

    <?php
    /* Start the Loop */
    while ( have_posts() ) :
      the_post();

      /*
       * Include the Post-Type-specific template for the content.
       * If you want to override this in a child theme, then include a file
       * called content-___.php (where ___ is the Post Type name) and that will be used instead.
       */
      get_template_part( 'template-parts/content', get_post_type() );

    endwhile; ?>

    <div class="styled-pagination text-center">
      <?php hostix_pagination();?>
    </div>

  <?php else :

    get_template_part( 'template-parts/content', 'none' );

  endif;
  ?>
  <?php
}

function hostix_search_loop(){ ?>

  <?php if ( have_posts() ) : ?>

    <?php
    /* Start the Loop */
    while ( have_posts() ) :
      the_post();

      /**
       * Run the loop for the search to output the results.
       * If you want to overload this in a child theme then include a file
       * called content-search.php and that will be used instead.
       */
      get_template_part( 'template-parts/content', 'search' );

    endwhile; ?>

    <div class="styled-pagination text-center">
      <?php hostix_pagination();?>
    </div>

  <?php else :

    get_template_part( 'template-parts/content', 'none' );

  endif;
  ?>
  <?php
}

function hostix_error_page(){
  $error_title = cs_get_option('error_title');
  $error_code = cs_get_option('error_code');
  $error_info_title = cs_get_option('error_info_title');
  $error_button = cs_get_option('error_button');
?>
  <div class="error-section">
    	<div class="auto-container">
        	<div class="content">
          <h1>
            <?php
                if(!empty($error_code)){
                    echo esc_html( $error_code );
                }else{
                    esc_html_e( '404', 'hostix' );
                }
            ?>
          </h1>
				<h2>
          <?php
              if(!empty($error_title)){
                  echo esc_html( $error_title );
              }else{
                  esc_html_e( 'Oops... It looks like you ‘re lost !', 'hostix' );
              }
          ?>
        </h2>
				<div class="text">
        <?php
              if(!empty($error_info_title)){
                  echo esc_html( $error_info_title );
              }else{
                  esc_html_e( 'Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'hostix' );
              }
          ?>

        </div>
				<!-- Button Box -->
				<div class="button-box text-center">
					<a href="index.html" class="theme-btn btn-style-one">
						<span class="btn-wrap">
							<span class="text-one">
                <?php
                    if(!empty($error_button)){
                        echo esc_html( $error_button );
                    }else{
                        esc_html_e( 'Go To Home', 'hostix' );
                    }
                ?>
              </span>
							<span class="text-two">
                <?php
                    if(!empty($error_button)){
                        echo esc_html( $error_button );
                    }else{
                        esc_html_e( 'Go To Home', 'hostix' );
                    }
                ?>
              </span>
						</span>
					</a>
				</div>
			</div>
		</div>
	</div>
<?php
}


// contact from 7 p tag remove
add_filter('wpcf7_autop_or_not', '__return_false');