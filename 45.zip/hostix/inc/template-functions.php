<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Hostix
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function hostix_body_classes( $classes ) {
    // Adds a class of hfeed to non-singular pages.
    if ( !is_singular() ) {
        $classes[] = 'hfeed';
    }

    // Adds a class of no-sidebar when there is no sidebar present.
    if ( !is_active_sidebar( 'sidebar-1' ) ) {
        $classes[] = 'no-sidebar';
    }

    return $classes;
}
add_filter( 'body_class', 'hostix_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function hostix_pingback_header() {
    if ( is_singular() && pings_open() ) {
        printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}
add_action( 'wp_head', 'hostix_pingback_header' );

/**
 * Authore Avater
 */
function hostix_main_author_avatars( $size ) {
    echo get_avatar( get_the_author_meta( 'email' ), $size );
}

add_action( 'genesis_entry_header', 'hostix_post_author_avatars' );

/**
 * Post Read Time
 */
function hostix_reading_time() {
    global $post;
    $content = get_post_field( 'post_content', $post->ID );
    $word_count = str_word_count( strip_tags( $content ) );
    $readingtime = ceil( $word_count / 200 );
    if ( $readingtime == 1 ) {
        $timer = esc_html__( " min read" );
    } else {
        $timer = esc_html__( " min read" );
    }
    $totalreadingtime = $readingtime . $timer;
    return $totalreadingtime;
}

/**
 * hostix Single Post Nav
 */
function hostix_single_post_pagination() {
    $hostix_prev_post = get_previous_post();
    $hostix_next_post = get_next_post();

    ?>
<div class="more-posts">
	<div class="more-posts-inner d-flex justify-content-between align-items-center">
		<div class="new-post">
		<a href="<?php echo esc_url( get_the_permalink( $hostix_prev_post ) ); ?>">
			<div class="prev-arrow fa fa-angle-left"></div>
		</a>
			<div class="post-inner <?php if ( !has_post_thumbnail( $hostix_prev_post ) ) {echo esc_attr( 'no__thmb_post' );}?>">
				<?php if ( has_post_thumbnail( $hostix_prev_post ) ): ?>
				<span class="image">
					<a href="<?php echo esc_url( get_the_permalink( $hostix_prev_post ) ); ?>"><img src="<?php echo esc_url( get_the_post_thumbnail_url( $hostix_prev_post, 'thumbnail' ) ); ?>" alt="<?php the_title_attribute();?>"></a>
				</span>
				<?php endif;?>
				<a href="<?php echo esc_url( get_the_permalink( $hostix_prev_post ) ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( $hostix_prev_post ), 7, '' ) ); ?></a>
				<div class="post-info"><span class="author"><?php hostix_main_author_avatars( 25 );?></span> <?php the_author()?> </div>
			</div>
		</div>
		<div class="new-post">
			<a href="<?php echo esc_url( get_the_permalink( $hostix_next_post ) ); ?>">
				<div class="next-arrow fa fa-angle-right"></div>
			</a>
			<div class="post-inner <?php if ( !has_post_thumbnail( $hostix_next_post ) ) {echo esc_attr( 'no__thmb_post' );}?>">
			<?php if ( has_post_thumbnail( $hostix_next_post ) ): ?>
				<span class="image">
					<a href="<?php echo esc_url( get_the_permalink( $hostix_next_post ) ); ?>"><img src="<?php echo esc_url( get_the_post_thumbnail_url( $hostix_next_post, 'thumbnail' ) ); ?>" alt="<?php the_title_attribute();?>"></a>
				</span>
				<?php endif;?>
				<a href="<?php echo esc_url( get_the_permalink( $hostix_next_post ) ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( $hostix_next_post ), 7, '' ) ); ?></a>
				<div class="post-info"><span class="author"><?php hostix_main_author_avatars( 25 );?></span> <?php the_author()?> </div>
			</div>
		</div>
	</div>
</div>
<?php
}

/**
 * Comment Message Box
 */
function hostix_comment_reform( $arg ) {

    $arg['title_reply'] = esc_html__( 'Leave a comment', 'hostix' );
    $arg['comment_field'] = '<div class="comments-form"><div class="col-lg-12 col-md-12 col-sm-12 form-group"><div class="field-item"><textarea id="comment" class="form_control" name="comment" cols="77" rows="3" placeholder="' . esc_attr__( "Comment", "hostix" ) . '" aria-required="true"></textarea></div></div></div>';

    return $arg;

}
add_filter( 'comment_form_defaults', 'hostix_comment_reform' );
/**
 * Comment Form Field
 */

function hostix_modify_comment_form_fields( $fields ) {
    $commenter = wp_get_current_commenter();
    $req = get_option( 'require_name_email' );

    $fields['author'] = '<div class="comment-form"><div class="row"><div class="col-lg-6 col-md-6 col-sm-12 form-group"><div class="field-item"><input type="text" name="author" id="author" value="' . esc_attr( $commenter['comment_author'] ) . '" placeholder="' . esc_attr__( "Name", "hostix" ) . '" size="22" tabindex="1"' . ( $req ? 'aria-required="true"' : '' ) . ' class="form_control" /></div></div>';

    $fields['email'] = '<div class="col-lg-6 col-md-6 col-sm-12 form-group"><div class="field-item"><input type="email" name="email" id="email" value="' . esc_attr( $commenter['comment_author_email'] ) . '" placeholder="' . esc_attr__( "Email", "hostix" ) . '" size="22" tabindex="2"' . ( $req ? 'aria-required="true"' : '' ) . ' class="form_control"  /></div></div>';

    $fields['url'] = '<div class="col-lg-12 col-md-12 col-sm-12 form-group"><div class="field-item"><input type="url" name="url" id="url" value="' . esc_attr( $commenter['comment_author_url'] ) . '" placeholder="' . esc_attr__( "Website", "hostix" ) . '" size="22" tabindex="2"' . ( $req ? 'aria-required="false"' : '' ) . ' class="form_control"  /></div></div></div></div>';

    return $fields;
}
add_filter( 'comment_form_default_fields', 'hostix_modify_comment_form_fields' );

// comment Move Field
function hostix_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}
add_filter( 'comment_form_fields', 'hostix_move_comment_field_to_bottom' );

/**
 * Comment List Modification
 */
function hostix_comments( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment;?>

	<li <?php comment_class();?> id="comment-<?php comment_ID()?>">
        <div class="comment-box">
			<div class="comment-item">
				<?php if ( get_avatar( $comment ) ) {?>
					<div class="author-thumb">
						<?php echo get_avatar( $comment, 82 ); ?>
					</div>
				<?php }?>

				<div class="comments-text">
					<div class="comment-info clearfix">
						<strong><?php comment_author_link()?></strong>
						<div class="comment-time"><?php echo date( get_option( 'date_format' ) ); ?></div>
						<?php comment_reply_link( array_merge( $args, [ 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => wp_kses( '<i class="fal fa-reply"></i> Reply', true ) ] ) );?>
					</div>
					<?php if ( $comment->comment_approved == '0' ): ?>
						<p><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'hostix' );?></em></p>
					<?php endif;?>
					<div class="text">
						<?php comment_text();?>
					</div>
				</div>
			</div>
        </div>
	</li>

<?php
}

/**
 * Search Widget
 */
function hostix_search_widgets( $form ) {
    $form = '
	<div class="search-box">
		<form role="search" method="get" id="searchform" class="widget__search" action="' . home_url( '/' ) . '" >
			<div class="form-group">
				<input class="form_control" placeholder="' . esc_attr__( 'Search Product', 'hostix' ) . '" type="text"  value="' . get_search_query() . '" name="s" id="s" />
				<button type="submit"><span class="icon fa fa-search"></span></button>
			</div>
		</form>
    </div>
	';

    return $form;
}
add_filter( 'get_search_form', 'hostix_search_widgets', 100 );

/**
 * Hostix Pagination
 */
function hostix_pagination() {
    global $wp_query;
    $links = paginate_links( [
        'current'   => max( 1, get_query_var( 'paged' ) ),
        'total'     => $wp_query->max_num_pages,
        'type'      => 'list',
        'mid_size'  => 3,
        'prev_text' => '<i class="fal fa-angle-double-left"></i>',
        'next_text' => '<i class="fal fa-angle-double-right"></i>',
    ] );

    echo wp_kses_post( $links );
}

function hostix_wp_nav_menu_objects( $items, $args ) { 

    foreach ( $items as &$item ) {

        $meta = get_post_meta( $item->ID, '_hoxtix_menu', true );

        if ( !empty( $meta['menu_icon'] ) ) {
            $item->title = '<i class="menuIcon ' . $meta['menu_icon'] . '"></i>' . $item->title;
        }
    }

    return $items;

}

add_filter( 'wp_nav_menu_objects', 'hostix_wp_nav_menu_objects', 10, 2 );
