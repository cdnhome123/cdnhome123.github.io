<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Hostix
 */

get_header();
hostix_single_post_breadcrumb();
$hostix_blog_layout = cs_get_option('hostix_blog_layout');
$hostixPostClass = '';
if(is_active_sidebar('sidebar-1')){
	$hostixPostClass = 'col-xl-9 col-lg-8 col-md-12 col-sm-12';
}else{
	$hostixPostClass = 'col-lg-10 offset-lg-1';
}
?>
<div class="sidebar-page-container">
	<div class="auto-container">
		<div class="row clearfix">
			
			<!-- Content Side -->
			<?php if('1' == $hostix_blog_layout):?>
			<?php get_sidebar();?>	
			<div class="content-side <?php echo esc_attr($hostixPostClass);?>">
				<!-- Blog Detail -->
				<div class="blog-detail">
					<?php hostix_single_post();?>
				</div>				
			</div>	
			<?php elseif('2' == $hostix_blog_layout):?>	
			<div class="content-side col-lg-10 offset-lg-1">
				<!-- Blog Detail -->
				<div class="blog-detail">
					<?php hostix_single_post();?>
				</div>				
			</div>	
			<?php else:?>
			<div class="content-side <?php echo esc_attr($hostixPostClass);?>">
				<!-- Blog Detail -->
				<div class="blog-detail">
					<?php hostix_single_post();?>
				</div>				
			</div>	
			<?php get_sidebar();?>	
			<?php endif;?>
		</div>
	</div>
</div>
<?php
get_footer();
