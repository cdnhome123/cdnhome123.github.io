<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Hostix
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<div class="sidebar-side col-xl-3 col-lg-4 col-md-12 col-sm-12">
	<aside id="secondary" class="widget-area sidebar sticky-top">
		<div class="sidebar-inner">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>		
	</aside><!-- #secondary -->
</div>
