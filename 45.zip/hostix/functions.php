<?php
/**
 * Hostix functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Hostix
 */


/**
 * Define Core FIle
*/
define( 'HOSTIX_THEME_DRI', get_template_directory() );
define( 'HOSTIX_THEME_URI', get_template_directory_uri() );
define( 'HOSTIX_CSS_PATH', HOSTIX_THEME_URI . '/assets/css' );
define( 'HOSTIX_JS_PATH', HOSTIX_THEME_URI . '/assets/js' );
define( 'HOSTIX_ICON_PATH', HOSTIX_THEME_URI . '/assets/fonts/fontawesome/css' );
define( 'HOSTIX_IMG_PATH', HOSTIX_THEME_URI . '/assets/images' );

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function hostix_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on Hostix, use a find and replace
		* to change 'hostix' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'hostix', get_template_directory() . '/languages' );
	remove_theme_support( 'widgets-block-editor' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	//Woocommerc
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	//Custom add image size
	add_image_size( 'hostix-image-size-1', 970, 520, true );
	add_image_size( 'hostix-image-size-2', 417, 277, true );
	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'main_menu' => esc_html__( 'Main Menu', 'hostix' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'hostix_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'hostix_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function hostix_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'hostix_content_width', 640 );
}
add_action( 'after_setup_theme', 'hostix_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function hostix_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'hostix' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'hostix' ),
			'before_widget' => '<div id="%1$s" class="widget sidebar-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<div class="sidebar-title"><h6>',
			'after_title'   => '</h6></div>',
		)
	);
	//Footer One
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer One', 'hostix' ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'Add widgets here.', 'hostix' ),
			'before_widget' => '<div id="%1$s" class="widget footer-widget links-widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5>',
			'after_title'   => '</h5>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Two', 'hostix' ),
			'id'            => 'footer-2',
			'description'   => esc_html__( 'Add widgets here.', 'hostix' ),
			'before_widget' => '<div id="%1$s" class="widget footer-widget links-widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5>',
			'after_title'   => '</h5>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Three', 'hostix' ),
			'id'            => 'footer-3',
			'description'   => esc_html__( 'Add widgets here.', 'hostix' ),
			'before_widget' => '<div id="%1$s" class="widget footer-widget links-widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5>',
			'after_title'   => '</h5>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Four', 'hostix' ),
			'id'            => 'footer-4',
			'description'   => esc_html__( 'Add widgets here.', 'hostix' ),
			'before_widget' => '<div id="%1$s" class="widget footer-widget links-widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5>',
			'after_title'   => '</h5>',
		)
	);
}
add_action( 'widgets_init', 'hostix_widgets_init' );


/**
 *Google Font Load
 */
if ( ! function_exists( 'hostix_fonts_url' ) ) :
	/**
	 * Register Google fonts for Blessing.
	 */
	function hostix_fonts_url() {
		$fonts_url     = '';
		$font_families = array();
		$subsets       = 'latin';

		if ( 'off' !== _x( 'on', 'Jost: on or off', 'hostix' ) ) {
			$font_families[] = 'Jost:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
		}

		if ( 'off' !== _x( 'on', 'Cabin: on or off', 'hostix' ) ) {
			$font_families[] = 'Cabin:400,400i,500,500i,600,600i,700,700i';
		}

		if ( 'off' !== _x( 'on', 'DM Sans: on or off', 'hostix' ) ) {
			$font_families[] = 'DM Sans:400,400i,500,500i,700,700i';
		}

		if ( 'off' !== _x( 'on', 'Roboto: on or off', 'hostix' ) ) {
			$font_families[] = 'Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i';
		}


		if ( $font_families ) {
			$fonts_url = add_query_arg( array(
				'family' => urlencode( implode( '|', $font_families ) ),
				'subset' => urlencode( $subsets ),
			), 'https://fonts.googleapis.com/css' );
		}

		return esc_url_raw( $fonts_url );
	}
	endif;

/**
 * Enqueue scripts and styles.
 */
function hostix_scripts() {
	//Hostix Google Font Load
	wp_enqueue_style( 'hostix-google-fonts', hostix_fonts_url(), array(), null );
	wp_enqueue_style( 'bootstrap', HOSTIX_CSS_PATH . '/bootstrap.css' );
	wp_enqueue_style( 'jquery-bootstrap-touchspin', HOSTIX_CSS_PATH . '/jquery.bootstrap-touchspin.css' );
	wp_enqueue_style( 'odometer-theme', HOSTIX_CSS_PATH . '/odometer-theme-default.css' );
	wp_enqueue_style( 'jquery-mCustomScrollbar', HOSTIX_CSS_PATH . '/jquery.mCustomScrollbar.min.css' );
	wp_enqueue_style( 'flaticon', HOSTIX_CSS_PATH . '/flaticon.css' );
	wp_enqueue_style( 'font-awesomes', HOSTIX_CSS_PATH . '/fontawesome.css' );
	wp_enqueue_style( 'icofont', HOSTIX_CSS_PATH . '/icofont.css' );
	wp_enqueue_style( 'animate', HOSTIX_CSS_PATH . '/animate.css' );
	wp_enqueue_style( 'owl-min', HOSTIX_CSS_PATH . '/owl.css' );
	wp_enqueue_style( 'swiper', HOSTIX_CSS_PATH . '/swiper.css' );
	wp_enqueue_style( 'magnific-popup', HOSTIX_CSS_PATH . '/magnific-popup.css' );
	wp_enqueue_style( 'meanmenu', HOSTIX_CSS_PATH . '/meanmenu.min.css' );
	wp_enqueue_style( 'custom-animate', HOSTIX_CSS_PATH . '/custom-animate.css' );
	wp_enqueue_style( 'preloader', HOSTIX_CSS_PATH . '/preloader.css' );
	wp_enqueue_style( 'hostix-global', HOSTIX_CSS_PATH . '/global.css' );
	wp_enqueue_style( 'hostix-header', HOSTIX_CSS_PATH . '/header.css' );
	wp_enqueue_style( 'hostix-footer', HOSTIX_CSS_PATH . '/footer.css' );
	wp_enqueue_style( 'hostix-post-style', HOSTIX_CSS_PATH . '/post-style.css' );
	wp_enqueue_style( 'hostix-main', HOSTIX_CSS_PATH . '/style.css' );
	wp_enqueue_style( 'hostix-responsive2', HOSTIX_CSS_PATH . '/responsive-2.css' );
	wp_enqueue_style( 'hostix-responsive', HOSTIX_CSS_PATH . '/responsive.css' );
	wp_enqueue_style( 'hostix-style', get_stylesheet_uri(), array(), '1.0' );
	if (is_rtl()) {
		wp_enqueue_style( 'hostix-rtl', HOSTIX_CSS_PATH . '/rtl.css' );
	}
	if ( class_exists('WooCommerce') ) {
		wp_enqueue_style( 'woocommerce-style', get_template_directory_uri() . '/woocommerce/woocommerce.css' );
	}

	// Js Enqueue
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script( 'popper', HOSTIX_JS_PATH . '/popper.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'bootstrap', HOSTIX_JS_PATH . '/bootstrap.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'magnific-popup', HOSTIX_JS_PATH . '/magnific-popup.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'appear', HOSTIX_JS_PATH . '/appear.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'parallax', HOSTIX_JS_PATH . '/parallax.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'jquery-paroller', HOSTIX_JS_PATH . '/jquery.paroller.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'mCustomScrollbar', HOSTIX_JS_PATH . '/jquery.mCustomScrollbar.concat.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'owl-min', HOSTIX_JS_PATH . '/owl.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'wow', HOSTIX_JS_PATH . '/wow.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'swiper', HOSTIX_JS_PATH . '/swiper.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'touchspin', HOSTIX_JS_PATH . '/touchspin.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'odometer', HOSTIX_JS_PATH . '/odometer.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'mixitup', HOSTIX_JS_PATH . '/mixitup.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'jquery-meanmenu', HOSTIX_JS_PATH . '/jquery.meanmenu.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'jquery-marquee', HOSTIX_JS_PATH . '/jquery.marquee.min.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'nav-tool', HOSTIX_JS_PATH . '/nav-tool.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'hostix-script', HOSTIX_JS_PATH . '/script.js', array('jquery'), '1.0', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'hostix_scripts' );

/**
 * Implement the Custom Header feature.
 */
require HOSTIX_THEME_DRI . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require HOSTIX_THEME_DRI . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require HOSTIX_THEME_DRI . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require HOSTIX_THEME_DRI . '/inc/customizer.php';

/**
 * Hostix Core Functions
 */
require HOSTIX_THEME_DRI . '/inc/hostix-functions.php';

/**
 * Hostix Metabox & Options Fremworks
 */
require HOSTIX_THEME_DRI . '/inc/cs-framework-functions.php';

/**
 * Hostix Metabox & Options Fremworks
 */
require HOSTIX_THEME_DRI . '/inc/class-wp-hostix-navwalker.php';

/**
 * Recommended Plugin Activation
 */
require HOSTIX_THEME_DRI . '/lib/plugin-activation.php';
/**
 * Insurin Theme Dynamic Style
 */
require HOSTIX_THEME_DRI . '/lib/ocdi/functions.php';

/**
 * Insurin Theme Dynamic Style
 */
require HOSTIX_THEME_DRI . '/inc/custom-style.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require HOSTIX_THEME_DRI . '/inc/jetpack.php';
}

/**
 * Remove Action Hook
 */

 function hostix_woo_theme_init(){
	$hostix_exlude_hooks = require HOSTIX_THEME_DRI . '/inc/remove_actions.php';
	foreach( $hostix_exlude_hooks as $k => $v )
	{
		foreach( $v as $value )
		remove_action( $k, $value[0], $value[1] );
	}

}
add_action( 'init', 'hostix_woo_theme_init');
